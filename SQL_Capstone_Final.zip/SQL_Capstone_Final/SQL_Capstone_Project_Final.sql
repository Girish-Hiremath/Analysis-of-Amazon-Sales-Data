SELECT * FROM amazon.amazon;
SELECT * FROM amazon.amazon;
use amazon;

-- 2.1 Add a new column named timeofday to give insight of sales in the Morning, Afternoon and Evening.
-- This will help answer the question on which part of the day most sales are made.
SELECT *,
  CASE
    WHEN EXTRACT(HOUR FROM time) BETWEEN 6 AND 11 THEN 'Morning'
    WHEN EXTRACT(HOUR FROM time) BETWEEN 12 AND 17 THEN 'Afternoon'
    WHEN EXTRACT(HOUR FROM time) BETWEEN 18 AND 23 THEN 'Evening'
    ELSE 'Night'
  END AS timeofday
  FROM amazon;
  -- 2.2 Add a new column named dayname that contains the extracted days of the week on which the given transaction took place (Mon, Tue, Wed, Thur, Fri).
  --  This will help answer the question on which week of the day each branch is busiest.
SELECT *, DATE_FORMAT(STR_TO_DATE(date, '%d-%m-%Y'), '%a') AS dayname
FROM amazon;
 
-- 2.3  Add a new column named monthname that contains the extracted months of the year on which the given transaction took place (Jan, Feb, Mar). 
-- Help determine which month of the year has the most sales and profit.
SELECT *, DATE_FORMAT(STR_TO_DATE(date, '%d-%m-%Y'), '%b') AS monthname
FROM amazon;

-- 1. What is the count of distinct cities in the dataset?

select count(distinct city) as distinct_city from amazon;

-- 2. For each branch, what is the corresponding city?

select  branch, city from amazon
group by branch,city;

-- 3. What is the count of distinct product lines in the dataset?
select count(distinct Product_line) from amazon;

-- 4. Which payment method occurs most frequently?
select payment, count(*) as ptype
from amazon
group by payment;

-- 5. Which product line has the highest sales?

select product_line, sum(quantity) as highest_sales
from amazon
group by product_line
order by product_line desc
limit 1;

-- 6.How much revenue is generated each month?

SELECT DATE_FORMAT(STR_TO_DATE(date, '%d-%m-%Y'), '%m') AS month,
  SUM(total) AS total_revenue
FROM amazon
GROUP BY month
ORDER BY month;

-- 7. In which month did the cost of goods sold reach its peak?

SELECT DATE_FORMAT(STR_TO_DATE(date, '%d-%m-%Y'), '%m') AS month,
  SUM(total) AS total_revenue
FROM amazon
GROUP BY month
ORDER BY total_revenue desc
limit 1;
-- 8. Which product line generated the highest revenue?


select product_line, sum(total) as highest_revenue
from amazon
group by product_line
order by product_line desc
limit 1;

-- 9. In which city was the highest revenue recorded?

select city, sum(total) as highest_revenue
from amazon
group by city
order by city desc
limit 1; 

-- 10. Which product line incurred the highest Value Added Tax?

select product_line, sum(tax_5) as highest_tax
from amazon
group by product_line
order by product_line desc
limit 1;

-- 11. For each product line, add a column indicating "Good" if its sales are above average, otherwise "Bad."

select product_line,sum(Total) as total_sale,
	case
    when sum(total) > 55000 then 'good'
    when sum(total) <= 55000  and sum(total) >=50000 then ' above average'
    when sum(total) < 50000  then 'bad'
end as result
from amazon
group by product_line
order by result;

-- 12. Identify the branch that exceeded the average number of products sold.



select branch, sum(quantity) as total_quantity
from amazon
group by branch
HAVING SUM(quantity) > (
  SELECT AVG(total_quantity)
  FROM (
    SELECT branch, SUM(quantity) AS total_quantity
    FROM amazon
    GROUP BY branch
  ) AS branch_totals
);


-- 13. Which product line is most frequently associated with each gender?

select product_line, gender, count(*)  as total_gender from amazon
group by gender, product_line
order by product_line;

-- 14. Calculate the average rating for each product line.

select product_line, avg(rating) as avg_rating
from amazon
group by product_line;

-- 15. Count the sales occurrences for each time of day on every weekday.

SELECT DAYNAME(STR_TO_DATE(Date, '%d-%m-%Y')) AS weekday,
    CASE
        WHEN HOUR(STR_TO_DATE(Time, '%H:%i:%s')) BETWEEN 6 AND 11 THEN 'Morning'
        WHEN HOUR(STR_TO_DATE(Time, '%H:%i:%s')) BETWEEN 12 AND 16 THEN 'Afternoon'
        WHEN HOUR(STR_TO_DATE(Time, '%H:%i:%s')) BETWEEN 17 AND 20 THEN 'Evening'
        ELSE 'Night'
    END AS time_of_day,COUNT(*) AS sales_count
FROM amazon
GROUP BY weekday, time_of_day
ORDER BY FIELD(weekday, 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'), time_of_day;

    
-- 16. Identify the customer type contributing the highest revenue.

select customer_type, sum(total) as high_revenue
from amazon
group by customer_type
limit 1;

-- 17. Determine the city with the highest VAT percentage.

SELECT * FROM amazon.amazon;
select city, sum(tax_5) as high_vat
from amazon
group by city
limit 1;

-- 18. Identify the customer type with the highest VAT payments.

select customer_type, sum(tax_5) as high_vat
from amazon
group by customer_type
limit 1;

-- 19. What is the count of distinct customer types in the dataset?

select count(distinct customer_type) as customer_type from amazon;

-- 20. What is the count of distinct payment methods in the dataset?

select count(distinct Payment) as customer_type from amazon;

-- 21. Which customer type occurs most frequently?

SELECT Customer_type, COUNT(*) AS frequency
FROM amazon
GROUP BY Customer_type
ORDER BY frequency DESC
LIMIT 1;

-- 22. Identify the customer type with the highest purchase frequency.

SELECT Customer_type, COUNT(quantity) AS frequency
FROM amazon
GROUP BY Customer_type
ORDER BY frequency DESC
LIMIT 1;

-- 23. Determine the predominant gender among customers.

SELECT gender, COUNT(*) AS predominant
FROM amazon
GROUP BY gender
ORDER BY predominant DESC
LIMIT 2;

-- 24. Examine the distribution of genders within each branch.

select branch, gender, count(*) as member from amazon
group by gender, branch
order by branch;

-- 25. Identify the time of day when customers provide the most ratings.


SELECT branch,
    CASE
        WHEN HOUR(STR_TO_DATE(Time, '%H:%i:%s')) BETWEEN 6 AND 11 THEN 'Morning'
        WHEN HOUR(STR_TO_DATE(Time, '%H:%i:%s')) BETWEEN 12 AND 16 THEN 'Afternoon'
        WHEN HOUR(STR_TO_DATE(Time, '%H:%i:%s')) BETWEEN 17 AND 20 THEN 'Evening'
        ELSE 'Night'
    END AS time_of_day,
    COUNT(*) AS rating_count

FROM amazon
GROUP BY time_of_day, branch
ORDER BY branch DESC
;

-- 26. Determine the time of day with the highest customer ratings for each branch.

WITH rating_counts AS ( SELECT branch,
        CASE
            WHEN HOUR(STR_TO_DATE(Time, '%H:%i:%s')) BETWEEN 6 AND 11 THEN 'Morning'
            WHEN HOUR(STR_TO_DATE(Time, '%H:%i:%s')) BETWEEN 12 AND 16 THEN 'Afternoon'
            WHEN HOUR(STR_TO_DATE(Time, '%H:%i:%s')) BETWEEN 17 AND 20 THEN 'Evening'
            ELSE 'Night'
        END AS time_of_day,
        COUNT(*) AS rating_count FROM amazon
    GROUP BY branch, time_of_day),
ranked AS (SELECT*, ROW_NUMBER() OVER (PARTITION BY branch ORDER BY rating_count DESC) AS rn
    FROM rating_counts
)
SELECT branch, time_of_day, rating_count
FROM ranked
WHERE rn = 1
ORDER BY branch;


-- 27. Identify the day of the week with the highest average ratings.

SELECT 
    DAYNAME(STR_TO_DATE(date, '%d-%m-%Y')) AS day_of_week,
    AVG(rating) AS average_rating
FROM amazon
GROUP BY DAYNAME(STR_TO_DATE(date, '%d-%m-%Y'))
ORDER BY average_rating DESC
LIMIT 1;


-- 28. Determine the day of the week with the highest average ratings for each branch.

WITH ratings_by_day AS (
    SELECT 
        branch,
        DAYNAME(STR_TO_DATE(date, '%d-%m-%Y')) AS day_of_week,
        AVG(rating) AS average_rating,
        ROW_NUMBER() OVER (PARTITION BY branch ORDER BY AVG(rating) DESC) AS ranks
    FROM amazon
    GROUP BY branch, DAYNAME(STR_TO_DATE(date, '%d-%m-%Y'))
)
SELECT branch, day_of_week, average_rating
FROM ratings_by_day
WHERE ranks = 1;
